"""Scaffold: sideways_regime.py"""
