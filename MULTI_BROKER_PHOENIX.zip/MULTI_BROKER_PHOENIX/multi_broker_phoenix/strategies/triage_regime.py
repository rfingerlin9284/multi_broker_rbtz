"""Scaffold: triage_regime.py"""
