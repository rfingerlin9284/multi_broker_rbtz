"""Scaffold: bearish_regime.py"""
