from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Dict
from .risk_manager import RiskManager

@dataclass
class TradeCandidate:
    strategy_id: str
    symbol: str
    platform: str
    entry_price: float
    stop_loss: float
    side: Optional[str] = None

@dataclass
class TradeDecision:
    allowed: bool
    reason: str
    risk_pct: float = 0.0
    size: float = 0.0

def _lookup_regime_multiplier(trend: str, vol: str, cfg: Dict) -> float:
    try:
        return float(cfg.get('regime_risk_multipliers', {}).get(trend, {}).get(vol, 0.0))
    except Exception:
        return 0.0

def can_open_trade(candidate: TradeCandidate, account_equity: float, rm: Optional[RiskManager] = None) -> TradeDecision:
    rm = rm or RiskManager()
    st = rm.state
    cfg = rm.config
    pol = st.policy
    if not rm.is_trading_allowed():
        return TradeDecision(False, 'risk_halt_or_brake')
    open_trades_on_platform = st.open_trades_by_platform.get(candidate.platform, 0)
    max_per_platform = pol.max_trades_per_platform if pol else int(cfg.get('platform_limits', {}).get(candidate.platform, {}).get('max_open_trades', 3))
    if open_trades_on_platform >= max_per_platform:
        return TradeDecision(False, 'platform_trade_cap')
    regimes = st.regime_by_symbol.get(candidate.symbol)
    if not regimes:
        return TradeDecision(False, 'missing_regime')
    trend = regimes.get('trend') or 'RANGE'
    vol = regimes.get('vol') or 'NORMAL'
    mult = _lookup_regime_multiplier(trend, vol, cfg)
    if mult <= 0.0:
        return TradeDecision(False, 'regime_disabled')
    base_risk = float(getattr(pol, 'base_risk_per_trade_pct', cfg.get('default_risk_per_trade_pct', 0.0075)))
    risk_pct = base_risk * mult
    cap = float(getattr(pol, 'max_open_risk_pct', cfg.get('max_total_open_risk_pct', 0.05)))
    if st.open_risk_pct + risk_pct > cap:
        return TradeDecision(False, 'open_risk_cap')
    if st.triage_mode:
        allowed = set(cfg.get('triage_allowed_strategies', ['institutional_sd','ema_scalper','trap_reversal','holy_grail']))
        if candidate.strategy_id not in allowed:
            return TradeDecision(False, 'triage_blocked')
    dist = abs(float(candidate.entry_price) - float(candidate.stop_loss))
    if dist <= 0:
        return TradeDecision(False, 'invalid_stop_distance')
    max_loss_money = float(account_equity) * float(risk_pct)
    size = max_loss_money / dist
    if size <= 0:
        return TradeDecision(False, 'size_below_minimum')
    return TradeDecision(True, 'OK', risk_pct=risk_pct, size=size)
