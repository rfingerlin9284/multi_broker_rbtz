# MULTI_BROKER_PHOENIX

A consolidated, safety-first multi-broker trading framework built around the RBOTZILLA Charter.

## Key guarantees
- **Platform breakers** (per-venue kill switches)
- **Execution gate** (global gate integrating risk state)
- **Trade risk gate** (halts/brakes, platform caps, open-risk caps, triage filtering, sizing via stop distance)
- **OCO-first mindset**: brokers/engines are expected to place orders with a stop-loss.

## Repo layout
- `multi_broker_phoenix/foundation/` Charter and governance rules
- `multi_broker_phoenix/risk/` Gates, breakers, and risk state/policy
- `multi_broker_phoenix/brokers/` Broker connectors (OANDA / Coinbase / IBKR)
- `multi_broker_phoenix/engines/` Per-venue engines
- `multi_broker_phoenix/config/` Non-secret config policies and toggles
- `tests/` Pytest suite validating core gate behavior
- `tools/` Versioning/locking helpers + git hooks

## Running tests
```bash
python -m pip install -r requirements.txt
pytest -q
```

## Versioning + read-only workflow (archive-first)
Edits must follow:
1. Archive current active file into `older_versions/` with `_v###` suffix
2. Promote an edited `.new` file
3. Lock active file as read-only

Use:
```bash
tools/version_and_lock.sh path/to/file.py
```

Enable hooks:
```bash
git config core.hooksPath .githooks
chmod +x .githooks/pre-commit tools/version_and_lock.sh
```
