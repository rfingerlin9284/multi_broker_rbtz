
import React, { useState, useEffect, useRef } from 'react';
import { createRoot } from 'react-dom/client';
import { 
  Shield, Activity, Terminal, TrendingUp, Cpu, Zap, Lock, Unlock, 
  AlertTriangle, RefreshCw, BarChart3, MessageSquare, ChevronRight, 
  Monitor, Database, Globe, Settings, Power, ArrowUpRight, ArrowDownRight,
  Wifi, Server, Layers, Crosshair, Target, ExternalLink, Clock, BarChart,
  HardDrive, History, Binary, Link as LinkIcon
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

// --- System Immutable Constraints (The "Hard-Code" Vault) ---
const PIN_REQUIRED = "841921";
const SYSTEM_VERSION = "v5.2.1-GOLD";
const MIN_TIMEFRAME_MINUTES = 5;
const CHARTER_HASH = "PHX-7R-A8F2-2025"; 

type BrokerName = 'OANDA' | 'Coinbase' | 'IBKR';
type Regime = 'BULL' | 'BEAR' | 'VOLATILE' | 'SIDEWAYS';

interface BrokerAccount {
  name: BrokerName;
  status: 'CONNECTED' | 'DISCONNECTED' | 'ERROR';
  bridgeHealth: number; // 0-100%
  balance: number;
  unrealizedPnL: number;
  activePositions: number;
  equity: number;
}

interface LogEntry {
  id: string;
  timestamp: string;
  type: 'ORDER' | 'SIGNAL' | 'SYSTEM' | 'GUARDIAN' | 'HIVE' | 'AUDIT' | 'BRIDGE';
  message: string;
  venue?: BrokerName;
  status?: 'SUCCESS' | 'FAILED' | 'BLOCKED';
}

const App = () => {
  const [isSystemEngaged, setIsSystemEngaged] = useState(false);
  const [mode, setMode] = useState<'PRACTICE' | 'LIVE'>('PRACTICE');
  const [showPinModal, setShowPinModal] = useState(false);
  const [pinValue, setPinValue] = useState("");
  const [pinError, setPinError] = useState(false);
  
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [aiAudit, setAiAudit] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [currentRegime, setCurrentRegime] = useState<Regime>('SIDEWAYS');
  const [engineHeat, setEngineHeat] = useState(42);

  const [brokers, setBrokers] = useState<Record<BrokerName, BrokerAccount>>({
    OANDA: { name: 'OANDA', status: 'DISCONNECTED', bridgeHealth: 0, balance: 2500, unrealizedPnL: 0, activePositions: 0, equity: 2500 },
    Coinbase: { name: 'Coinbase', status: 'DISCONNECTED', bridgeHealth: 0, balance: 1500, unrealizedPnL: 0, activePositions: 0, equity: 1500 },
    IBKR: { name: 'IBKR', status: 'DISCONNECTED', bridgeHealth: 0, balance: 2000, unrealizedPnL: 0, activePositions: 0, equity: 2000 },
  });

  const terminalRef = useRef<HTMLDivElement>(null);

  const addLog = (entry: Omit<LogEntry, 'id' | 'timestamp'>) => {
    const newLog: LogEntry = {
      ...entry,
      id: Math.random().toString(36).substring(2, 9),
      timestamp: new Date().toLocaleTimeString(),
    };
    setLogs(prev => [newLog, ...prev].slice(0, 50));
  };

  useEffect(() => {
    if (!isSystemEngaged) return;

    const stream = setInterval(() => {
      setEngineHeat(prev => Math.min(95, Math.max(30, prev + (Math.random() * 4 - 2))));
      
      setBrokers(prev => ({
        ...prev,
        OANDA: { ...prev.OANDA, status: 'CONNECTED', bridgeHealth: 98, equity: prev.OANDA.equity + (Math.random() * 2 - 1) },
        Coinbase: { ...prev.Coinbase, status: 'CONNECTED', bridgeHealth: 95, equity: prev.Coinbase.equity + (Math.random() * 5 - 2.5) },
        IBKR: { ...prev.IBKR, status: 'CONNECTED', bridgeHealth: 100, equity: prev.IBKR.equity + (Math.random() * 10 - 4) }
      }));

      if (Math.random() > 0.95) {
        addLog({ 
          type: 'BRIDGE', 
          message: `IBKR Connector: Latency 12ms. TWS session synced. Logic: ibkr_connector.py`,
          venue: 'IBKR'
        });
      }
    }, 3000);

    return () => clearInterval(stream);
  }, [isSystemEngaged]);

  const runDriftAudit = async () => {
    setIsAnalyzing(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Evaluate the 5m timeframe floor adherence in the logs for all brokers. Specifically audit the new IBKR Python bridge for logic drift. Logs: ${JSON.stringify(logs.slice(0, 15))}`,
        config: { thinkingConfig: { thinkingBudget: 3000 } }
      });
      setAiAudit(response.text || "Audit failed.");
    } catch (e) {
      setAiAudit("Error connecting to Strat-Brain.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleLiveUnlock = () => {
    if (pinValue === PIN_REQUIRED) {
      setMode('LIVE');
      setShowPinModal(false);
      setPinValue("");
      addLog({ type: 'AUDIT', message: "AUTHORITY VERIFIED: IBKR/OANDA Production authorized.", status: 'SUCCESS' });
    } else {
      setPinError(true);
      setPinValue("");
    }
  };

  return (
    <div className="min-h-screen bg-[#020202] text-[#e0e0e0] font-mono selection:bg-blue-500/30">
      <div className="h-10 bg-[#080808] border-b border-white/10 flex items-center justify-between px-6 text-[10px] font-black uppercase tracking-widest text-gray-500">
        <div className="flex gap-6">
          <div className="flex items-center gap-2"><Server className="w-3 h-3 text-blue-500" /> NODE: RICK_WSL_PROD</div>
          <div className="flex items-center gap-2"><Binary className="w-3 h-3 text-green-500" /> HASH: {CHARTER_HASH}</div>
        </div>
        <div className="flex gap-6 text-white">
          <div className="flex items-center gap-2"><Activity className="w-3 h-3 text-orange-500" /> ENGINE_HEAT: {engineHeat.toFixed(1)}°C</div>
          <span>OS: {SYSTEM_VERSION}</span>
        </div>
      </div>

      <header className="border-b border-white/5 bg-[#0a0a0a]/90 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-[1600px] mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-blue-600 rounded flex items-center justify-center shadow-[0_0_20px_rgba(37,99,235,0.4)]">
              <Zap className="text-white fill-current w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-black text-white italic tracking-tighter uppercase leading-none">PHOENIX <span className="text-blue-500">V2</span></h1>
              <p className="text-[10px] text-gray-500 font-bold mt-1 tracking-widest uppercase">Decoupled Command Center</p>
            </div>
          </div>

          <div className="flex items-center gap-8">
            <div className="hidden xl:flex gap-6">
              {Object.values(brokers).map(b => (
                <div key={b.name} className="flex flex-col items-end border-r border-white/10 pr-6 last:border-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[8px] text-gray-500 font-black uppercase tracking-tighter">{b.name} BRIDGE</span>
                    <div className={`w-1 h-1 rounded-full ${b.status === 'CONNECTED' ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`}></div>
                  </div>
                  <span className={`text-sm font-black tabular-nums ${b.status === 'CONNECTED' ? 'text-green-400' : 'text-red-400'}`}>
                    ${b.equity.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                </div>
              ))}
            </div>

            <button 
              onClick={() => setIsSystemEngaged(!isSystemEngaged)}
              className={`px-10 py-3 rounded font-black uppercase text-xs tracking-[0.2em] transition-all border ${
                isSystemEngaged 
                ? 'bg-red-500/10 text-red-500 border-red-500/30 hover:bg-red-500/20' 
                : 'bg-blue-600 text-white border-blue-500/50 hover:bg-blue-500 shadow-[0_0_30px_rgba(37,99,235,0.3)]'
              }`}
            >
              {isSystemEngaged ? 'ENGINE SUSPEND' : 'ENGINE ENGAGE'}
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-[1600px] mx-auto p-6 grid grid-cols-12 gap-6">
        <div className="col-span-12 lg:col-span-4 space-y-6">
          <div className="bg-[#0f0f0f] border border-white/10 rounded-xl p-5">
             <h3 className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-4">Python Broker Adapters</h3>
             <div className="space-y-4">
                {Object.values(brokers).map(b => (
                  <div key={b.name} className="space-y-2 group">
                    <div className="flex items-center justify-between px-1">
                      <span className="text-[10px] font-bold text-white uppercase">{b.name} Endpoint</span>
                      <span className="text-[9px] font-mono text-gray-600">{b.bridgeHealth}% Signal</span>
                    </div>
                    <div className="h-1 bg-black rounded-full overflow-hidden border border-white/5">
                      <div className="h-full bg-blue-500 transition-all duration-1000 group-hover:bg-blue-400" style={{ width: `${b.bridgeHealth}%` }}></div>
                    </div>
                    <div className="flex items-center justify-between text-[8px] font-black uppercase tracking-tighter text-gray-600">
                      <span>{b.name === 'IBKR' ? 'FILE: ibkr_connector.py' : 'REST_SYNC'}</span>
                      <span className={b.status === 'CONNECTED' ? 'text-green-500' : 'text-red-500'}>{b.status}</span>
                    </div>
                  </div>
                ))}
             </div>
          </div>

          <div className="bg-[#0f0f0f] border border-white/10 rounded-xl p-6">
             <h3 className="text-xs font-black text-blue-500 uppercase tracking-[0.2em] mb-6 flex items-center gap-2">
                <Shield className="w-4 h-4" /> Hardened Vault Constraints
             </h3>
             <div className="space-y-3">
                <div className="p-3 bg-black/50 border border-white/5 rounded flex items-center justify-between">
                   <span className="text-[10px] text-gray-400 uppercase font-bold">Timeframe Min Floor</span>
                   <span className="text-xs font-black text-white">{MIN_TIMEFRAME_MINUTES} MIN</span>
                </div>
                <div className="p-3 bg-black/50 border border-white/5 rounded flex items-center justify-between">
                   <span className="text-[10px] text-gray-400 uppercase font-bold">IBKR Port (TWS)</span>
                   <span className="text-xs font-black text-white">7497</span>
                </div>
                <div className="p-3 bg-black/50 border border-white/5 rounded flex items-center justify-between">
                   <span className="text-[10px] text-gray-400 uppercase font-bold">Execution Gate</span>
                   <span className="text-xs font-black text-green-500">FAIL_CLOSED</span>
                </div>
             </div>
          </div>

          <div className={`p-6 rounded-xl border-2 transition-all duration-700 ${mode === 'LIVE' ? 'bg-red-500/5 border-red-500/40 shadow-[0_0_40px_rgba(239,68,68,0.1)]' : 'bg-blue-500/5 border-blue-500/20'}`}>
             <h2 className="text-2xl font-black text-white italic uppercase mb-2 tracking-tighter">{mode} DEPLOYMENT</h2>
             <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest mb-8">Authorizing Production Connectors</p>
             <button 
               onClick={() => mode === 'LIVE' ? setMode('PRACTICE') : setShowPinModal(true)}
               className={`w-full py-5 rounded font-black text-sm uppercase tracking-[0.3em] transition-all border ${
                 mode === 'LIVE' 
                 ? 'border-red-500/50 text-red-500 hover:bg-red-500 hover:text-white' 
                 : 'border-blue-500/50 text-blue-500 hover:bg-blue-500 hover:text-white shadow-[0_0_20px_rgba(37,99,235,0.1)]'
               }`}
             >
               {mode === 'LIVE' ? 'Relinquish Live Rights' : 'Authorize Python Bridge'}
             </button>
          </div>
        </div>

        <div className="col-span-12 lg:col-span-8 space-y-6">
          {/* Gemini Strategy Auditor */}
          <div className="bg-[#080c14] border border-blue-900/30 rounded-xl p-8 group relative overflow-hidden">
             <div className="absolute top-0 right-0 p-8 opacity-5">
                <Binary className="w-32 h-32" />
             </div>
             <div className="flex items-center justify-between mb-8">
                <div>
                   <h2 className="text-2xl font-black text-white italic uppercase tracking-tighter">Strat-Brain Logic Auditor</h2>
                   <p className="text-[10px] text-blue-500 font-black uppercase tracking-widest mt-1">Detecting Agent Drift & Charter Violations</p>
                </div>
                <button 
                  onClick={runDriftAudit}
                  disabled={isAnalyzing || !isSystemEngaged}
                  className="bg-blue-600 hover:bg-blue-500 disabled:opacity-30 text-white text-[10px] font-black uppercase px-8 py-4 rounded-sm transition-all flex items-center gap-2 shadow-lg"
                >
                  {isAnalyzing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Crosshair className="w-5 h-5" />}
                  Perform Compliance Scan
                </button>
             </div>
             <div className="bg-black/60 border border-white/5 rounded p-6 min-h-[200px] text-sm text-gray-300 relative">
                {aiAudit ? (
                  <div className="prose prose-invert max-w-none font-sans leading-relaxed">
                    {aiAudit.split('\n').map((l, i) => <p key={i} className="mb-2">{l}</p>)}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-48 opacity-20">
                    <History className="w-12 h-12 mb-4 animate-pulse" />
                    <p className="uppercase font-black text-xs tracking-widest">Awaiting Bridge Execution Data...</p>
                  </div>
                )}
             </div>
          </div>

          {/* Terminal / Log Session */}
          <div className="bg-[#050505] border border-white/10 rounded-xl overflow-hidden flex flex-col h-[550px] shadow-2xl">
             <div className="bg-[#111] p-4 border-b border-white/10 flex items-center justify-between">
                <div className="flex items-center gap-3">
                   <Terminal className="w-4 h-4 text-green-500" />
                   <h3 className="text-xs font-black text-white uppercase tracking-wider">Audit Trail :: BRIDGE_SESSION</h3>
                </div>
                <div className="flex gap-4 items-center">
                   <span className="text-[9px] font-mono text-gray-600">ID: RICK-7R-PROD</span>
                   <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.5)]"></div>
                </div>
             </div>
             <div className="flex-1 overflow-y-auto p-4 space-y-1 font-mono text-[11px]" ref={terminalRef}>
                {logs.map(log => (
                  <div key={log.id} className="flex items-start gap-4 p-2 hover:bg-white/5 rounded-sm transition-all border-l-2 border-transparent hover:border-blue-500/50">
                     <span className="text-gray-600 tabular-nums shrink-0">[{log.timestamp}]</span>
                     <div className="flex flex-col flex-1">
                        <div className="flex items-center gap-2 mb-0.5">
                           <span className={`px-2 py-0.5 rounded-[1px] font-black uppercase text-[8px] tracking-widest ${
                             log.type === 'GUARDIAN' ? 'bg-orange-600 text-white' :
                             log.type === 'ORDER' ? 'bg-green-600 text-black' :
                             log.type === 'BRIDGE' ? 'bg-blue-600 text-white' : 'bg-gray-800 text-gray-400'
                           }`}>
                                {log.type}
                           </span>
                           {log.venue && <span className="text-[8px] text-gray-600 font-bold uppercase">@{log.venue}</span>}
                        </div>
                        <span className="text-gray-300 leading-tight">{log.message}</span>
                     </div>
                  </div>
                ))}
             </div>
             <div className="p-4 bg-[#0a0a0a] border-t border-white/5">
                <input 
                  type="text" 
                  placeholder="EXECUTE BRIDGE COMMAND (e.g. IBKR:BUY:SPY:500)..."
                  className="bg-black border border-white/10 w-full rounded p-4 px-6 text-xs text-white uppercase font-bold focus:outline-none focus:border-blue-500 placeholder:text-gray-800 tracking-wider"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      addLog({ type: 'ORDER', message: `Manual Dispatch Command: ${e.currentTarget.value}`, venue: 'IBKR', status: 'SUCCESS' });
                      e.currentTarget.value = '';
                    }
                  }}
                />
             </div>
          </div>
        </div>
      </main>

      {showPinModal && (
        <div className="fixed inset-0 z-[100] bg-black/98 backdrop-blur-2xl flex items-center justify-center p-6 animate-in fade-in duration-300">
          <div className="max-w-md w-full bg-[#0a0a0a] border border-white/10 p-12 rounded-3xl relative shadow-[0_0_100px_rgba(239,68,68,0.1)]">
            <div className="absolute top-0 left-0 w-full h-1.5 bg-red-600"></div>
            <div className="flex flex-col items-center text-center">
              <AlertTriangle className="w-16 h-16 text-red-500 mb-8 animate-pulse" />
              <h2 className="text-3xl font-black text-white italic uppercase mb-4 tracking-tighter">Bridge Authorization</h2>
              <p className="text-gray-500 text-xs mb-10 font-bold uppercase tracking-widest leading-relaxed">
                Confirm production access for <br/><span className="text-red-500">ibkr_connector.py</span>
              </p>
              <input 
                type="password"
                maxLength={6}
                value={pinValue}
                onChange={(e) => setPinValue(e.target.value)}
                placeholder="••••••"
                className="w-full bg-black border border-white/10 rounded-2xl p-6 text-center text-6xl tracking-[0.5em] font-black text-white focus:outline-none focus:border-blue-500 mb-8"
              />
              <button 
                onClick={handleLiveUnlock}
                className="w-full bg-red-600 hover:bg-red-500 text-white font-black py-6 rounded-2xl transition-all uppercase tracking-[0.4em] shadow-xl text-lg active:scale-95"
              >
                 Authorize Session
              </button>
            </div>
          </div>
        </div>
      )}

      <footer className="max-w-[1600px] mx-auto p-12 pt-0 flex flex-col md:flex-row items-center justify-between gap-12 opacity-30 hover:opacity-100 transition-all duration-700">
        <div className="flex items-center gap-12 text-[10px] font-black uppercase tracking-[0.4em]">
           <div className="flex items-center gap-3">
              <Database className="w-4 h-4 text-blue-500" /> WSL_BACKEND: ibkr_connector.py (ACTIVE)
           </div>
           <div className="flex items-center gap-3 text-orange-500">
              <Shield className="w-4 h-4" /> GUARDIAN: 5m_TFR_GATE (LOCKED)
           </div>
        </div>
        <div className="text-[11px] font-black text-gray-800 uppercase tracking-widest">
          Autonomous Quantitative Engine © 2025 :: RICK STRAT-LABS
        </div>
      </footer>
    </div>
  );
};

const container = document.getElementById('root');
if (container) {
  const root = createRoot(container);
  root.render(<App />);
}
