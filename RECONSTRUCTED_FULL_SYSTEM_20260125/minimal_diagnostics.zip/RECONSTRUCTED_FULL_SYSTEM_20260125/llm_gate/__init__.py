"""Local LLM gate modules."""
